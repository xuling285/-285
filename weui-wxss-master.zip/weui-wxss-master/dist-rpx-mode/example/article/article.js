Page({
  mixins: [require('../../mixin/common')],
});
